AAREADME.txt
============

The contents of this ZIP archive are the NEAR catalog files as they were 
being served from the /n/pds/www/html/missions/near/catalog directory
via the adjacent web pages as of 03 December 2009.  

On 04 December 2009, these were (for the most part) replaced with versions
that had been edited and updated by Tilden Barnes in an effort to merge
information from the different versions that existed in the PDS central
catalog and the SBN website.  These had diverged because of things added
to the EN database (like new DATA_SET_ catalog object fields for 
CITATION_DESC) to the original catalog files from the CD/DVD images 
ingested some years agao, and updates made after initial archiving on
the electronic copies actually presented to the web users at SBN.
____________________________

04 December 2009, A.C.Raugh.
